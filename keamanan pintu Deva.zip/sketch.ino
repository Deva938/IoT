#define BLYNK_TEMPLATE_ID "TMPL6444IYihJ"
#define BLYNK_TEMPLATE_NAME "keamanan pintu"
#define BLYNK_AUTH_TOKEN "_MaM_QU-QBpu3vlpJbvcpIeMsEzwb3MS"

#define BLYNK_PRINT Serial
#include <WiFi.h>
#include <BlynkSimpleEsp32.h>

char ssid[] = "Wokwi-GUEST";
char pass[] = "";

const int pirPin = 27;    
const int buzzerPin = 26; 
const int ledPin = 25;    

bool sistemAktif = true;  
int statusGerak = LOW;

BlynkTimer timer;

BLYNK_WRITE(V0) {
  int tombol = param.asInt();
  if (tombol == 1) {
    sistemAktif = true;
    Serial.println("Sistem Keamanan: AKTIF");
  } else {
    sistemAktif = false;
    digitalWrite(ledPin, LOW);
    noTone(buzzerPin);
    if (Blynk.connected()) Blynk.virtualWrite(V1, "NONAKTIF");
    Serial.println("Sistem Keamanan: NONAKTIF");
  }
}

void cekKeamanan() {
  if (!sistemAktif) return;

  statusGerak = digitalRead(pirPin);

  if (statusGerak == HIGH) {
    digitalWrite(ledPin, HIGH);
    tone(buzzerPin, 1000);
    if (Blynk.connected()) Blynk.virtualWrite(V1, "BAHAYA! ADA GERAKAN");
    Serial.println("PERINGATAN: Gerakan Terdeteksi!");
  } else {
    digitalWrite(ledPin, LOW);
    noTone(buzzerPin);
    if (Blynk.connected()) Blynk.virtualWrite(V1, "RUANGAN AMAN");
  }
}

void setup() {
  Serial.begin(115200);
  pinMode(pirPin, INPUT);
  pinMode(buzzerPin, OUTPUT);
  pinMode(ledPin, OUTPUT);

  Serial.print("Menghubungkan ke WiFi Wokwi");
  WiFi.begin(ssid, pass, 6); // Channel 6 mempercepat koneksi WiFi Wokwi
  while (WiFi.status() != WL_CONNECTED) {
    delay(250);
    Serial.print(".");
  }
  Serial.println("\nWiFi Terhubung!");

  // Konfigurasi non-blocking agar alat tetap jalan meski server Blynk lambat
  Blynk.config(BLYNK_AUTH_TOKEN, "blynk.cloud", 80);
  Blynk.connect(5000); // Mencoba konek maksimal 5 detik

  if (Blynk.connected()) {
    Serial.println("Berhasil Terhubung ke Blynk!");
    Blynk.virtualWrite(V0, 1);
  } else {
    Serial.println("Blynk gagal konek (Cek Token/Server), tapi sensor tetap aktif!");
  }

  timer.setInterval(500L, cekKeamanan);
}

void loop() {
  if (Blynk.connected()) {
    Blynk.run();
  }
  timer.run();
}